module Model.PersonalDetails exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, classList, id)

-- Definirea tipului de date pentru detalii cu nume
type alias DetailWithName =
    { name : String
    , detail : String
    }

-- Definirea tipului de date pentru detalii personale
type alias PersonalDetails =
    { name : String
    , contacts : List DetailWithName
    , intro : String
    , socials : List DetailWithName
    }
-- Functie pt afisarea detaliilor personale

view : PersonalDetails -> Html msg
view details =
     div [] [
        h1 [id "name"] [],
        em [id "intro"] [],
        div [class "contact-detail"] (List.map (\x -> p [class "contact-detail"] [text x.name]) details.contacts),
        div [class "social-link"] (List.map (\x -> p [class "social-link"] [text x.name]) details.socials)
            ]
    --Debug.todo "Implement the Model.PersonalDetails.view function"
